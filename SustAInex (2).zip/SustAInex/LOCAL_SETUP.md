Local setup

1. Install dependencies

```bash
npm install
```

2. Run dev server

```bash
npm run dev
```
