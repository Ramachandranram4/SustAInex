# SustAInex 🌍🚨

**AI-Powered Smart City Disaster Response Platform**

Report disasters in real-time. Get instant analysis, guidance, and automatic alerts to emergency services—all powered by Google Gemini 3.

### What It Does
- 🔍 Analyzes incident photos/videos for type and severity
- 📍 Detects your location automatically
- 💬 Provides guidance in your language
- 🚨 Alerts fire, police, and medical services via SMS
- 🗺️ Shows incidents on a live map
---
## ✨ Features

1. **Incident Detection** - AI vision analysis (Fire, Flood, Accident, Collapse, etc.)
2. **Location Detection** - Automatic GPS/IP detection
3. **Smart Guidance** - AI-powered precautions and action steps
4. **Multilingual** - Auto-translates to Tamil, Kannada, Hindi, Telugu, Bengali, etc.
5. **Live Map** - View incidents and emergency resources
6. **Authority Alerts** - Automatic SMS to emergency services
7. **Community Feed** - Real-time incident reports

---

## 🏗️ Tech Stack

**Frontend:** Next.js 15 • React 18 • TypeScript • Tailwind CSS • Radix UI (40+ components)

**AI:** Google Gemini 3 • Genkit Framework

**Utilities:** Leaflet (maps) • Recharts (charts) • Lucide Icons

**Optional:** Twilio (SMS) • Cloudinary (media storage)

---

## 📋 Quick Start

### Prerequisites
- Node.js 18+
- npm or yarn
- Gemini API key (free at https://ai.google.dev)

### Installation (3 steps)

```bash
# 1. Install dependencies
npm install

# 2. Create .env file with:
GEMINI_API_KEY=your_key_here
GOOGLE_GENAI_API_KEY=your_key_here

# 3. Start dev server
npm run dev
```

Open http://localhost:9002 ✨

---

## 📖 How to Use

1. **Upload** - Click "Upload" and select an incident image/video
2. **Select Language** - Choose English, Hindi, or Regional Language
3. **View Results** - Get incident analysis, precautions, and action steps
4. **See Map** - View your location and nearby emergency services
5. **Auto Alert** - Authorities notified automatically via SMS
6. **Community Feed** - Check other incident reports in your area

---

## 🗂️ Project Structure

```
src/
├── app/              # Main dashboard
├── ai/               # AI flows & Genkit setup
├── components/       # UI components
├── hooks/            # Custom hooks
├── lib/              # Utilities
└── types/            # TypeScript definitions
```

---

## 🎨 Design

- **Dark mode** optimized for emergency situations
- **Responsive** - Works on desktop, tablet, mobile
- **Accessible** - WCAG compliant with Radix UI
- **Fast** - Next.js server components for performance

---

## 🚀 Commands

```bash
npm run dev      # Start development server
npm run build    # Build for production
npm start        # Start production server
npm run lint     # Run linter
```

## 🐛 Troubleshooting

**Port 9002 already in use?**
```bash
Get-Process -Name node | Stop-Process -Force
npm run dev
```

**API key not working?**
- Check `.env` file exists
- Verify key is correct and copied fully
- Restart dev server

**Module not found?**
```bash
npm install
```

---



---
