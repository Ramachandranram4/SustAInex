const fs = require('fs');
const path = require('path');

const folders = [
  'src/ai/flows',
  'src/app',
  'src/components/ui',
  'src/lib',
  'src/hooks',
];

console.log('--- Initializing SmartCity Sentinel Structure ---');

folders.forEach(folder => {
  const dirPath = path.join(process.cwd(), folder);
  if (!fs.existsSync(dirPath)) {
    fs.mkdirSync(dirPath, { recursive: true });
    console.log(`Created: ${folder}`);
  }
});

console.log('\nSuccess! Directories are ready.');
console.log('1. Copy the file contents from the XML block in the chat into their respective local files.');
console.log('2. Run "npm install"');
console.log('3. Run "npm run dev"');