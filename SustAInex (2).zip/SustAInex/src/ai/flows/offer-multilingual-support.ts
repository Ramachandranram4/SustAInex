'use server';
/**
 * @fileOverview This file implements the global multilingual support feature for the Smart City Sentinel platform.
 *
 * - detectAndTranslate - Detects the target language and translates the situation analysis, precautions, and instructions.
 * - MultilingualSupportInput - The input type for the detectAndTranslate function.
 * - MultilingualSupportOutput - The return type for the detectAndTranslate function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const MultilingualSupportInputSchema = z.object({
  city: z.string().describe('The city of the incident.'),
  state: z.string().describe('The state of the incident.'),
  country: z.string().optional().describe('The country of the incident.'),
  latitude: z.number().describe('The latitude of the incident.'),
  longitude: z.number().describe('The longitude of the incident.'),
  situationAnalysis: z.string().describe('The analysis of the situation.'),
  precautions: z.string().describe('The precautions to take.'),
  whatToDoNow: z.string().describe('Step-by-step guidance for the user.'),
  targetLanguage: z.string().optional().describe('Manually specified target language.'),
});
export type MultilingualSupportInput = z.infer<typeof MultilingualSupportInputSchema>;

const MultilingualSupportOutputSchema = z.object({
  translatedSituationAnalysis: z.string().describe('The translated analysis of the situation.'),
  translatedPrecautions: z.string().describe('The translated precautions to take.'),
  translatedWhatToDoNow: z.string().describe('The translated step-by-step guidance for the user.'),
  language: z.string().describe('The language used for translation.'),
});
export type MultilingualSupportOutput = z.infer<typeof MultilingualSupportOutputSchema>;

export async function detectAndTranslate(input: MultilingualSupportInput): Promise<MultilingualSupportOutput> {
  return multilingualSupportFlow(input);
}

const getGlobalLanguage = (city: string, state: string, country?: string, target?: string): string => {
  if (target && target !== 'Regional Language' && target !== 'Detecting...') return target;
  
  const c = (city || '').toLowerCase();
  const s = (state || '').toLowerCase();
  const co = (country || '').toLowerCase();

  // Global Mappings
  if (co.includes('china') || c.includes('beijing') || c.includes('shanghai')) return 'Chinese';
  if (co.includes('japan') || c.includes('tokyo') || c.includes('osaka')) return 'Japanese';
  if (co.includes('germany') || c.includes('berlin') || c.includes('munich')) return 'German';
  if (co.includes('france') || c.includes('paris')) return 'French';
  if (co.includes('brazil') || co.includes('portugal')) return 'Portuguese';
  if (co.includes('spain') || co.includes('mexico') || co.includes('argentina') || co.includes('madrid')) return 'Spanish';
  if (co.includes('italy') || c.includes('rome') || c.includes('milan')) return 'Italian';
  if (co.includes('russia') || c.includes('moscow')) return 'Russian';
  if (co.includes('korea') || c.includes('seoul')) return 'Korean';

  // Indian States
  if (s.includes('tamil') || c.includes('chennai')) return 'Tamil';
  if (s.includes('karnataka') || c.includes('bangalore') || c.includes('bengaluru')) return 'Kannada';
  if (s.includes('maharashtra') || c.includes('mumbai') || c.includes('pune')) return 'Marathi';
  if (s.includes('telangana') || s.includes('andhra') || c.includes('hyderabad')) return 'Telugu';
  if (s.includes('west bengal') || c.includes('kolkata')) return 'Bengali';
  if (s.includes('gujarat') || c.includes('ahmedabad')) return 'Gujarati';
  if (s.includes('kerala') || c.includes('kochi')) return 'Malayalam';
  if (s.includes('delhi') || s.includes('uttar') || s.includes('bihar') || s.includes('madhya') || s.includes('haryana')) return 'Hindi';
  
  return 'English'; // Default global fallback
};

const prompt = ai.definePrompt({
  name: 'multilingualSupportPrompt',
  input: {
    schema: z.object({
      language: z.string(),
      situationAnalysis: z.string(),
      precautions: z.string(),
      whatToDoNow: z.string(),
    })
  },
  output: {schema: MultilingualSupportOutputSchema},
  prompt: `You are an expert translator specializing in emergency communications. 

CRITICAL: You MUST translate the following emergency information into the native script of {{language}}. 
For example:
- Chinese -> Simplified Chinese Characters
- Japanese -> Kanji/Hiragana/Katakana
- Hindi -> Devanagari script
- Tamil -> Tamil script
- Kannada -> Kannada script
- German -> German (standard)
- Portuguese -> Portuguese (standard)

Do NOT use Romanized characters in the output fields. Use the actual native characters.

Original Information to Translate:
Situation Analysis: {{{situationAnalysis}}}
Precautions: {{{precautions}}}
What To Do Now: {{{whatToDoNow}}}

Your response must be a valid JSON object matching the output schema with all content translated into {{language}}.`,
});

const multilingualSupportFlow = ai.defineFlow(
  {
    name: 'multilingualSupportFlow',
    inputSchema: MultilingualSupportInputSchema,
    outputSchema: MultilingualSupportOutputSchema,
  },
  async (input: any) => {
    const language = getGlobalLanguage(input.city, input.state, input.country, input.targetLanguage);
    
    const {output} = await prompt({
      language: language,
      situationAnalysis: input.situationAnalysis,
      precautions: input.precautions,
      whatToDoNow: input.whatToDoNow,
    });

    if (!output) {
      throw new Error('Translation core failed to return output.');
    }

    return {
      translatedSituationAnalysis: output.translatedSituationAnalysis,
      translatedPrecautions: output.translatedPrecautions,
      translatedWhatToDoNow: output.translatedWhatToDoNow,
      language: language,
    };
  }
);
