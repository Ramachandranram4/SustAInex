"use client";

import React, { useState, useEffect, useRef, useMemo } from 'react';
import dynamic from 'next/dynamic';
import { ChatPanel } from '@/components/ChatPanel';
import { UploadSection } from '@/components/UploadSection';
import { SettingsModal } from '@/components/SettingsModal';
import { FeedPanel } from '@/components/FeedPanel';
import { LogsPanel } from '@/components/LogsPanel';
import { KORAMANGALA_LOCATION, UserLocation, getCurrentLocation } from '@/lib/location';
import { analyzeUploadedMediaForIncident, AnalyzeUploadedMediaOutput } from '@/ai/flows/analyze-uploaded-media-for-incident';
import { detectAndTranslate } from '@/ai/flows/offer-multilingual-support';
import { provideSituationalAwareness } from '@/ai/flows/provide-situational-awareness';
import { sendEmergencyAlert } from '@/ai/flows/send-emergency-alert';
import { Toaster } from '@/components/ui/toaster';
import { useToast } from '@/hooks/use-toast';
import { Activity, ShieldCheck, Radio, History, LayoutDashboard, MapPin, Search, Loader2, Globe, Settings, MessageSquare, ChevronUp, Bell, Users } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

const MapPanel = dynamic(() => import('@/components/MapPanel').then((mod) => mod.MapPanel), { 
  ssr: false,
  loading: () => (
    <div className="w-full h-full bg-[#1a1a1a] flex items-center justify-center rounded-[2.5rem] border border-border/50 animate-pulse">
       <Activity className="w-12 h-12 text-primary" />
    </div>
  )
});

// Community Feed Data - will be populated from real incident reports
const MOCK_FEED: any[] = [];

export default function Home() {
  const [mounted, setMounted] = useState(false);
  const [location, setLocation] = useState<UserLocation>(KORAMANGALA_LOCATION);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisProgress, setAnalysisProgress] = useState(0);
  const [pendingResult, setPendingResult] = useState<AnalyzeUploadedMediaOutput | null>(null);
  const [incidentData, setIncidentData] = useState<AnalyzeUploadedMediaOutput | null>(null);
  const [activeLanguage, setActiveLanguage] = useState('English');
  const [isEmergencyActive, setIsEmergencyActive] = useState(false);
  const [showLanguageSelect, setShowLanguageSelect] = useState(false);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [searchQuery, setSearchQuery] = useState('');
  const [suggestions, setSuggestions] = useState<any[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [myIncidents, setMyIncidents] = useState<any[]>([]);

  const { toast } = useToast();
  const suggestionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setMounted(true);
  }, []);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (suggestionRef.current && !suggestionRef.current.contains(event.target as Node)) {
        setShowSuggestions(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  useEffect(() => {
    const fetchSuggestions = async () => {
      if (searchQuery.length < 3) {
        setSuggestions([]);
        return;
      }
      try {
        const response = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(searchQuery)}&addressdetails=1&limit=5`);
        const data = await response.json();
        setSuggestions(data);
        setShowSuggestions(true);
      } catch (error) {
        console.error("Failed to fetch suggestions:", error);
      }
    };
    const debounceTimer = setTimeout(fetchSuggestions, 500);
    return () => clearTimeout(debounceTimer);
  }, [searchQuery]);

  const regionalLanguageName = useMemo(() => {
    const c = (location.city || '').toLowerCase();
    const s = (location.state || '').toLowerCase();
    const co = (location.country || '').toLowerCase();

    if (co.includes('china') || c.includes('beijing')) return 'Chinese';
    if (co.includes('japan') || c.includes('tokyo')) return 'Japanese';
    if (co.includes('germany') || c.includes('berlin')) return 'German';
    if (co.includes('france') || c.includes('paris')) return 'French';
    if (co.includes('brazil') || co.includes('portugal')) return 'Portuguese';
    if (co.includes('spain') || co.includes('mexico')) return 'Spanish';
    if (co.includes('italy')) return 'Italian';
    if (co.includes('russia')) return 'Russian';
    if (co.includes('korea')) return 'Korean';

    if (s.includes('tamil') || c.includes('chennai')) return 'Tamil';
    if (s.includes('karnataka') || c.includes('bangalore') || c.includes('bengaluru')) return 'Kannada';
    if (s.includes('maharashtra') || c.includes('mumbai') || c.includes('pune')) return 'Hindi';
    if (s.includes('telangana') || s.includes('andhra') || c.includes('hyderabad')) return 'Telugu';
    if (s.includes('west bengal') || c.includes('kolkata')) return 'Bengali';
    
    return 'Regional Language';
  }, [location.state, location.city, location.country]);

  const handleUpload = async (dataUri: string) => {
    setIsAnalyzing(true);
    setAnalysisProgress(0);
    const interval = setInterval(() => {
      setAnalysisProgress(prev => {
        if (prev >= 98) return prev;
        return prev + Math.random() * 8;
      });
    }, 300);

    try {
      const result = await analyzeUploadedMediaForIncident({
        mediaDataUri: dataUri,
        userLatitude: location.latitude,
        userLongitude: location.longitude,
      });
      clearInterval(interval);
      setAnalysisProgress(100);
      setTimeout(() => {
        setIsAnalyzing(false);
        setPendingResult(result);
        setShowLanguageSelect(true);
      }, 1000);
    } catch (error: any) {
      clearInterval(interval);
      setIsAnalyzing(false);
      toast({ variant: "destructive", title: "SCAN FAILED", description: error.message });
    }
  };

  const handleLanguageChoice = async (langType: 'english' | 'regional' | 'hindi') => {
    if (!pendingResult) return;
    setIsProcessing(true);
    setShowLanguageSelect(false);
    const langName = langType === 'english' ? 'English' : (langType === 'hindi' ? 'Hindi' : regionalLanguageName);
    setActiveLanguage(langName);
    
    // Extract severity level without emoji
    const severityMap: { [key: string]: string } = {
      '🟢 Low': 'Low',
      '🟡 Medium': 'Medium',
      '🔴 High': 'High',
    };
    const cleanSeverity = severityMap[pendingResult.severity] || 'High';
    
    try {
      let finalResult = pendingResult;
      
      // Get situational awareness
      try {
        const awareness = await provideSituationalAwareness({
          incidentType: pendingResult.incidentType,
          locationCity: location.city || '',
          locationState: location.state || '',
          latitude: location.latitude,
          longitude: location.longitude,
          severityLevel: cleanSeverity,
          nearbyFireStations: '2-3 km away',
          nearbyHospitals: '1-2 km away',
          nearbyPoliceStations: '1.5 km away',
        });
        finalResult = {
          ...pendingResult,
          situationAnalysis: awareness.situationAnalysis,
          precautions: awareness.precautions,
          whatToDoNow: awareness.whatToDoNow,
        };
      } catch (e) {
        console.error('Situational awareness failed:', e);
      }

      // Translate if needed
      if (langName !== 'English') {
        try {
          const translated = await detectAndTranslate({
            city: location.city || '',
            state: location.state || '',
            country: location.country || '',
            latitude: location.latitude,
            longitude: location.longitude,
            situationAnalysis: finalResult.situationAnalysis,
            precautions: finalResult.precautions,
            whatToDoNow: finalResult.whatToDoNow,
            targetLanguage: langName,
          });
          finalResult = { ...finalResult, situationAnalysis: translated.translatedSituationAnalysis, precautions: translated.translatedPrecautions, whatToDoNow: translated.translatedWhatToDoNow };
        } catch (e) {
          console.error('Translation failed:', e);
        }
      }

      // Send emergency alert
      try {
        await sendEmergencyAlert({
          situationAnalysis: finalResult.situationAnalysis,
          precautions: finalResult.precautions,
          whatToDoNow: finalResult.whatToDoNow,
          authoritiesToBeAlerted: pendingResult.authoritiesToBeAlerted,
          language: langName,
          message: `${pendingResult.incidentType} incident detected at ${location.city}, ${location.state}. Severity: ${cleanSeverity}. Precautions: ${finalResult.precautions}`,
          credentials: {
            accountSid: process.env.NEXT_PUBLIC_TWILIO_ACCOUNT_SID || 'test-account',
            authToken: process.env.NEXT_PUBLIC_TWILIO_AUTH_TOKEN || 'test-token',
            from: process.env.NEXT_PUBLIC_TWILIO_FROM || '+1234567890',
            to: '+919876543210', // Default emergency number - can be made configurable
          },
        });
      } catch (e) {
        console.error('Emergency alert failed:', e);
      }

      finalizeIncident(finalResult);
    } catch (e) {
      finalizeIncident(pendingResult);
    } finally {
      setIsProcessing(false);
    }
  };

  const finalizeIncident = (data: AnalyzeUploadedMediaOutput) => {
    setIncidentData(data);
    setMyIncidents(prev => [{ ...data, id: Date.now().toString(), time: 'Just now', locationName: location.city }, ...prev]);
    setIsEmergencyActive(true);
    setActiveTab('dashboard');
  };

  const handleGlobalReset = () => {
    setIncidentData(null);
    setPendingResult(null);
    setIsEmergencyActive(false);
    setAnalysisProgress(0);
    toast({ title: "DASHBOARD RESET", description: "All active incident nodes cleared." });
  };

  const handleLocationModeChange = async (mode: string) => {
    if (mode === 'fixed') setLocation(KORAMANGALA_LOCATION);
    else if (mode === 'gps') setLocation(await getCurrentLocation());
    else setLocation(prev => ({ ...prev, mode: 'manual' }));
  };

  const handleSelectSuggestion = (item: any) => {
    const address = item.address;
    const city = address.city || address.town || address.village || address.suburb || 'Selected Area';
    setLocation({ 
      latitude: parseFloat(item.lat), 
      longitude: parseFloat(item.lon), 
      city: city, 
      state: address.state || 'Manual', 
      country: address.country || 'Unknown', 
      mode: 'manual' 
    });
    setSearchQuery(city);
    setShowSuggestions(false);
    setActiveTab('dashboard');
  };

  const jumpToLocation = (loc: { lat: number, lng: number }, name: string) => {
    setLocation(prev => ({ ...prev, latitude: loc.lat, longitude: loc.lng, city: name, mode: 'manual' }));
    setActiveTab('dashboard');
    toast({ title: "GRID REDIRECT", description: `Synchronizing satellite to ${name}` });
  };

  if (!mounted) return null;

  return (
    <Tabs value={activeTab} onValueChange={setActiveTab} className="h-screen bg-[#080808] text-white flex flex-col font-body selection:bg-primary overflow-hidden">
      <header className="h-20 px-6 border-b border-white/5 glass-morphism flex items-center justify-between sticky top-0 z-[110]">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-primary flex items-center justify-center shadow-[0_0_20px_rgba(41,171,226,0.5)]">
            <ShieldCheck className="w-6 h-6 text-white" />
          </div>
          <h1 className="text-xl font-black tracking-tighter uppercase hidden xs:block">Sentinel</h1>
        </div>

        <div className="hidden md:flex flex-1 max-w-xl mx-8">
           <div className="relative w-full" ref={suggestionRef}>
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} placeholder="Search global grid..." className="w-full bg-white/5 border-white/10 rounded-2xl pl-12 h-12 text-sm font-bold uppercase tracking-widest placeholder:opacity-30" />
            {showSuggestions && suggestions.length > 0 && (
              <div className="absolute top-full mt-3 left-0 right-0 glass-morphism rounded-3xl shadow-[0_30px_60px_rgba(0,0,0,0.6)] z-[200] overflow-hidden border border-white/10">
                {suggestions.map((item, idx) => (
                  <button key={idx} onClick={() => handleSelectSuggestion(item)} className="w-full px-6 py-4 text-left text-xs font-black hover:bg-primary/20 border-b border-white/5 last:border-0 truncate flex items-center gap-3 transition-colors uppercase tracking-widest">
                    <MapPin className="w-4 h-4 text-primary shrink-0" /> {item.display_name}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        <div className="flex items-center gap-4">
          <Select onValueChange={handleLocationModeChange} value={location.mode === 'fixed' ? 'fixed' : (location.mode === 'gps' ? 'gps' : 'manual')}>
            <SelectTrigger className="w-[120px] bg-white/5 border-white/10 rounded-full h-10 text-[10px] font-black uppercase tracking-widest hover:bg-white/10 transition-colors">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="glass-morphism border-white/10 text-white rounded-2xl">
              <SelectItem value="fixed">Fixed Grid</SelectItem>
              <SelectItem value="gps">Live GPS</SelectItem>
              <SelectItem value="manual">Manual Entry</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="ghost" size="icon" onClick={() => setIsSettingsOpen(true)} className="rounded-2xl w-10 h-10 hover:bg-white/10">
            <Settings className="w-5 h-5 text-muted-foreground" />
          </Button>
        </div>
      </header>

      <main className="flex-1 relative overflow-hidden h-[calc(100vh-80px-70px)] md:h-[calc(100vh-80px)]">
        <TabsContent value="dashboard" className="h-full m-0">
          <div className="flex flex-col md:flex-row h-full p-4 md:p-6 gap-4 md:gap-6 overflow-hidden">
            <div className="flex-[1.8] relative h-[45%] md:h-full order-1 md:order-1">
              <MapPanel location={location} incidentType={incidentData?.incidentType} severity={incidentData?.severity} />
            </div>
            <div className="flex-1 h-[55%] md:h-full overflow-y-auto order-2 md:order-2">
              {!isEmergencyActive ? (
                <UploadSection onUpload={handleUpload} isProcessing={isAnalyzing} progress={analysisProgress} location={location} />
              ) : (
                <div className="flex flex-col gap-4 h-full">
                  <ChatPanel initialData={incidentData!} activeLanguage={activeLanguage} locationContext={location} onReset={handleGlobalReset} />
                </div>
              )}
            </div>
          </div>
        </TabsContent>
        
        <TabsContent value="feed" className="h-full m-0 overflow-y-auto">
          <FeedPanel feed={myIncidents.length > 0 ? myIncidents : []} onSelect={jumpToLocation} />
        </TabsContent>

        <TabsContent value="incidents" className="h-full m-0 overflow-y-auto">
          <LogsPanel incidents={myIncidents} />
        </TabsContent>
      </main>

      {/* Desktop Navigation (Tabs) */}
      <div className="hidden md:flex h-[60px] bg-[#121212] border-t border-white/10 items-center justify-center">
        <TabsList className="bg-transparent border-0 p-0 flex gap-12 h-full">
          <TabsTrigger value="dashboard" className="flex items-center gap-2 data-[state=active]:bg-transparent data-[state=active]:text-primary transition-all">
            <LayoutDashboard className="w-5 h-5" />
            <span className="text-[10px] font-black uppercase tracking-widest">Live Grid</span>
          </TabsTrigger>
          <TabsTrigger value="feed" className="flex items-center gap-2 data-[state=active]:bg-transparent data-[state=active]:text-primary transition-all">
            <Radio className="w-5 h-5" />
            <span className="text-[10px] font-black uppercase tracking-widest">Community Feed</span>
          </TabsTrigger>
          <TabsTrigger value="incidents" className="flex items-center gap-2 data-[state=active]:bg-transparent data-[state=active]:text-primary transition-all">
            <History className="w-5 h-5" />
            <span className="text-[10px] font-black uppercase tracking-widest">Sentinel Logs</span>
          </TabsTrigger>
        </TabsList>
      </div>

      {/* Mobile Bottom Navigation */}
      <div className="md:hidden h-[70px] bg-[#121212]/90 backdrop-blur-2xl border-t border-white/10 flex items-center justify-around px-4 mobile-nav-shadow">
        <TabsList className="bg-transparent border-0 p-0 flex w-full justify-around h-full">
          <TabsTrigger value="dashboard" className="flex flex-col items-center gap-1.5 data-[state=active]:bg-transparent data-[state=active]:text-primary transition-all">
            <LayoutDashboard className="w-6 h-6" />
            <span className="text-[9px] font-black uppercase">Grid</span>
          </TabsTrigger>
          <TabsTrigger value="feed" className="flex flex-col items-center gap-1.5 data-[state=active]:bg-transparent data-[state=active]:text-primary transition-all">
            <Radio className="w-6 h-6" />
            <span className="text-[9px] font-black uppercase">Feed</span>
          </TabsTrigger>
          <TabsTrigger value="incidents" className="flex flex-col items-center gap-1.5 data-[state=active]:bg-transparent data-[state=active]:text-primary transition-all">
            <History className="w-6 h-6" />
            <span className="text-[9px] font-black uppercase">Logs</span>
          </TabsTrigger>
        </TabsList>
      </div>

      {showLanguageSelect && (
        <div className="fixed inset-0 z-[250] bg-black/90 backdrop-blur-2xl flex items-center justify-center p-6 animate-in fade-in duration-500">
          <div className="max-w-md w-full glass-morphism rounded-[3rem] p-12 space-y-10 text-center border border-primary/20 shadow-[0_0_100px_rgba(41,171,226,0.1)]">
            <div className="w-20 h-20 bg-primary/20 rounded-[2rem] flex items-center justify-center mx-auto border border-primary/30">
               <MessageSquare className="w-10 h-10 text-primary animate-bounce" />
            </div>
            <div className="space-y-2">
              <h2 className="text-3xl font-black uppercase tracking-tighter leading-none">Language Protocol</h2>
              <p className="text-[10px] font-black text-muted-foreground uppercase tracking-widest">Select Regional Interface Locale</p>
            </div>
            <div className="grid grid-cols-1 gap-4">
              <Button onClick={() => handleLanguageChoice('english')} className="h-16 rounded-2xl text-lg font-black uppercase tracking-widest bg-white/5 border border-white/10 hover:bg-primary transition-all shadow-xl">English (INTL)</Button>
              {regionalLanguageName !== 'Regional Language' && (
                <Button onClick={() => handleLanguageChoice('regional')} className="h-16 rounded-2xl text-lg font-black uppercase tracking-widest bg-white/5 border border-white/10 hover:bg-primary transition-all shadow-xl">{regionalLanguageName}</Button>
              )}
              <Button onClick={() => handleLanguageChoice('hindi')} className="h-16 rounded-2xl text-lg font-black uppercase tracking-widest bg-white/5 border border-white/10 hover:bg-primary transition-all shadow-xl">Hindi (Bharat)</Button>
            </div>
          </div>
        </div>
      )}

      {isProcessing && (
        <div className="fixed inset-0 z-[300] bg-black/60 backdrop-blur-md flex items-center justify-center animate-in fade-in duration-300">
          <div className="flex flex-col items-center gap-6">
            <Loader2 className="w-12 h-12 text-primary animate-spin" />
            <p className="text-xs font-black uppercase tracking-[0.4em] text-primary animate-pulse">Detecting...</p>
          </div>
        </div>
      )}

      <SettingsModal isOpen={isSettingsOpen} onClose={() => setIsSettingsOpen(false)} />
      <Toaster />
    </Tabs>
  );
}
