
"use client";

import React, { useState, useEffect } from 'react';
import { Bot, PhoneCall, RotateCcw, AlertTriangle, Activity, Volume2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';
import { generateSpeech } from '@/ai/flows/generate-speech';

export function ChatPanel({ initialData, activeLanguage = 'English', onReset }: any) {
  const [messages, setMessages] = useState<any[]>([]);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    if (initialData) setMessages([{ id: 'rich', role: 'bot', rich: true }]);
  }, [initialData]);

  const handleSpeech = async () => {
    if (isSpeaking) return;
    setIsSpeaking(true);
    try {
      const textToSpeak = `${initialData.type}. ${initialData.description}. ${initialData.severity}`;
      const response = await generateSpeech({ text: textToSpeak, language: activeLanguage });
      const audio = new Audio(response.media);
      audio.onended = () => setIsSpeaking(false);
      audio.play();
    } catch (error: any) {
      setIsSpeaking(false);
      toast({ variant: "destructive", title: "VOICE UPLINK FAILED", description: error.message });
    }
  };

  return (
    <div className="flex flex-col h-full bg-card/40 backdrop-blur-xl border border-white/10 rounded-[2rem] overflow-hidden">
      <div className="p-5 border-b border-white/5 bg-white/5 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Bot className="w-6 h-6 text-primary" />
          <h3 className="text-xs font-black uppercase tracking-widest">Sentinel Core</h3>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="outline" className="text-[10px] font-black uppercase border-primary/30 text-primary">{activeLanguage}</Badge>
          <Button onClick={onReset} variant="ghost" size="icon" className="w-8 h-8 rounded-full hover:bg-white/10">
            <RotateCcw className="w-4 h-4" />
          </Button>
        </div>
      </div>

      <ScrollArea className="flex-1 p-5">
        {messages.map((m) => (
          <div key={m.id} className="mb-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
            {m.rich ? (
              <div className="bg-white/5 border border-white/10 rounded-[1.5rem] p-6 space-y-6">
                <div className="flex items-center justify-between">
                  <div className="flex flex-col gap-2">
                    <div className="flex items-center gap-2">
                      <AlertTriangle className="w-4 h-4 text-primary" />
                      <h4 className="text-sm font-black uppercase text-primary">{initialData.type}</h4>
                    </div>
                    <Badge variant="outline" className="w-fit text-red-500 border-red-500 uppercase font-black text-[9px]">{initialData.severity}</Badge>
                  </div>
                  <Button onClick={handleSpeech} disabled={isSpeaking} variant="ghost" size="icon" className="w-12 h-12 rounded-2xl bg-primary/10 border border-primary/20 hover:bg-primary/20">
                    <Volume2 className={`w-6 h-6 text-primary ${isSpeaking ? 'animate-pulse' : ''}`} />
                  </Button> 
                </div>
                <Separator className="bg-white/5" />
                <div className="space-y-4">
                  <div className="space-y-1">
                    <h5 className="text-[10px] font-black uppercase text-primary flex items-center gap-2"><Activity className="w-3 h-3" /> Analysis</h5>
                    <p className="text-xs text-white/90 leading-relaxed">{initialData.description}</p>
                  </div>
                </div>
              </div>
            ) : (
              <div className="p-4 rounded-2xl bg-white/5 text-[11px]">{m.text}</div>
            )}
          </div>
        ))}
      </ScrollArea>

      <div className="p-6 border-t border-white/5">
        <Button className="w-full bg-primary h-14 rounded-2xl font-black uppercase tracking-widest text-xs gap-3">
          <PhoneCall className="w-5 h-5" />
          OPS DISPATCH
        </Button>
      </div>
    </div>
  );
}
