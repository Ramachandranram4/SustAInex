"use client";

import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { MapPin, Users, Clock, AlertTriangle, ChevronRight } from 'lucide-react';
import Image from 'next/image';

interface FeedPanelProps {
  feed: any[];
  onSelect: (loc: { lat: number, lng: number }, name: string) => void;
}

export function FeedPanel({ feed, onSelect }: FeedPanelProps) {
  return (
    <div className="p-6 space-y-8 animate-in fade-in duration-500 max-w-4xl mx-auto">
      <div className="space-y-2">
        <div className="inline-flex items-center gap-2 px-3 py-1 bg-primary/20 border border-primary/30 rounded-full text-primary text-[10px] font-black tracking-widest uppercase">
          <Users className="w-3 h-3" />
          Global Incident Network
        </div>
        <h2 className="text-4xl font-black tracking-tighter text-white uppercase leading-none">
          COMMUNITY <span className="text-primary">FEED</span>
        </h2>
        <p className="text-xs font-bold text-muted-foreground uppercase tracking-widest opacity-60">Real-time situational awareness from citizens</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {feed.map((item) => (
          <Card key={item.id} className="group relative bg-[#121212]/50 border-white/10 hover:border-primary/50 transition-all rounded-[2rem] overflow-hidden cursor-pointer shadow-2xl" onClick={() => onSelect(item.location, item.locationName)}>
            <div className="relative h-48 w-full overflow-hidden">
               <Image src={item.image} alt={item.type} fill className="object-cover group-hover:scale-105 transition-transform duration-700" />
               <div className="absolute inset-0 bg-gradient-to-t from-[#121212] via-transparent to-transparent" />
               <Badge className="absolute top-4 right-4 bg-red-500/80 backdrop-blur-md border-0 text-[10px] font-black uppercase px-3 py-1 rounded-full">{item.severity}</Badge>
            </div>
            
            <CardContent className="p-6 space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-primary font-black text-xs">
                    {item.user[0]}
                  </div>
                  <div>
                    <h4 className="text-[11px] font-black text-white uppercase leading-none">{item.user}</h4>
                    <span className="text-[9px] font-bold text-muted-foreground uppercase tracking-widest">{item.time}</span>
                  </div>
                </div>
                <div className="flex items-center gap-1.5 text-primary text-[10px] font-black uppercase">
                  <MapPin className="w-3 h-3" /> {item.locationName}
                </div>
              </div>

              <div className="space-y-2">
                <h3 className="text-lg font-black uppercase text-white tracking-tight leading-none group-hover:text-primary transition-colors">{item.type}</h3>
                <p className="text-xs text-muted-foreground font-medium leading-relaxed line-clamp-2">{item.description}</p>
              </div>

              <div className="flex items-center justify-between pt-2 border-t border-white/5">
                 <span className="text-[9px] font-black text-primary/60 uppercase tracking-widest">Grid Coordinates Active</span>
                 <Button variant="ghost" size="sm" className="h-8 rounded-full text-[10px] font-black uppercase hover:bg-primary/20 gap-2">
                   Live View <ChevronRight className="w-3 h-3" />
                 </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
