"use client";

import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { History, ShieldCheck, MapPin, Activity, Calendar, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface LogsPanelProps {
  incidents: any[];
}

export function LogsPanel({ incidents }: LogsPanelProps) {
  return (
    <div className="p-6 space-y-8 animate-in slide-in-from-right duration-500 max-w-4xl mx-auto">
      <div className="flex items-center justify-between">
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-green-500/20 border border-green-500/30 rounded-full text-green-500 text-[10px] font-black tracking-widest uppercase">
            <History className="w-3 h-3" />
            Personal Incident Archives
          </div>
          <h2 className="text-4xl font-black tracking-tighter text-white uppercase leading-none">
            SENTINEL <span className="text-primary">LOGS</span>
          </h2>
        </div>
        <Button variant="outline" className="rounded-full border-white/10 h-10 px-6 gap-2 text-[10px] font-black uppercase hover:bg-white/5 transition-all">
          <Download className="w-4 h-4" /> Export Report
        </Button>
      </div>

      {incidents.length === 0 ? (
        <Card className="bg-white/5 border-dashed border-white/10 rounded-[2.5rem] py-20 flex flex-col items-center gap-6 opacity-30">
          <ShieldCheck className="w-16 h-16 text-primary" />
          <p className="text-xs font-black uppercase tracking-[0.3em]">No incident records detected in local grid</p>
        </Card>
      ) : (
        <div className="space-y-4">
          {incidents.map((inc) => (
            <Card key={inc.id} className="bg-white/5 border-white/10 rounded-3xl overflow-hidden hover:bg-white/10 transition-all">
              <CardContent className="p-6 flex flex-col md:flex-row gap-6 items-start md:items-center">
                <div className="w-16 h-16 rounded-2xl bg-primary/20 border border-primary/30 flex items-center justify-center shrink-0">
                  <Activity className="w-8 h-8 text-primary" />
                </div>
                
                <div className="flex-1 space-y-2">
                  <div className="flex flex-wrap gap-3 items-center">
                    <Badge className="bg-red-500/80 text-[10px] font-black uppercase px-3 py-1 rounded-full">{inc.severity}</Badge>
                    <h3 className="text-lg font-black uppercase text-white tracking-tight">{inc.incidentType}</h3>
                    <div className="flex items-center gap-2 text-muted-foreground text-[10px] font-black uppercase tracking-widest">
                       <Calendar className="w-3.5 h-3.5" /> {inc.time}
                    </div>
                  </div>
                  <p className="text-xs text-white/60 font-medium line-clamp-1">{inc.situationAnalysis}</p>
                </div>

                <div className="flex items-center gap-4 w-full md:w-auto pt-4 md:pt-0 border-t md:border-0 border-white/5">
                  <div className="flex items-center gap-2 text-primary text-[10px] font-black uppercase bg-primary/10 px-4 py-2 rounded-full border border-primary/20">
                    <MapPin className="w-3.5 h-3.5" /> {inc.locationName || 'Unknown Node'}
                  </div>
                  <Button variant="ghost" className="h-10 w-10 rounded-full border border-white/10 text-muted-foreground hover:text-white">
                    <ShieldCheck className="w-5 h-5" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
