"use client";

import React, { useEffect, useState, useMemo } from 'react';
import dynamic from 'next/dynamic';
import { useMap } from 'react-leaflet';
import { Navigation, Activity } from 'lucide-react';

const MapContainer = dynamic(() => import('react-leaflet').then((mod) => mod.MapContainer), { ssr: false });
const TileLayer = dynamic(() => import('react-leaflet').then((mod) => mod.TileLayer), { ssr: false });
const Marker = dynamic(() => import('react-leaflet').then((mod) => mod.Marker), { ssr: false });
const Popup = dynamic(() => import('react-leaflet').then((mod) => mod.Popup), { ssr: false });
const Circle = dynamic(() => import('react-leaflet').then((mod) => mod.Circle), { ssr: false });

function ChangeView({ center, zoom }: { center: [number, number], zoom: number }) {
  const map = useMap();
  useEffect(() => {
    map.setView(center, zoom, {
      animate: true,
      duration: 1.5
    });
  }, [center, zoom, map]);
  return null;
}

interface MapPanelProps {
  location: { latitude: number; longitude: number; city?: string; state?: string };
  incidentType?: string;
  severity?: string;
}

export function MapPanel({ location, incidentType, severity }: MapPanelProps) {
  const [isMounted, setIsMounted] = useState(false);
  const [leafletLib, setLeafletLib] = useState<any>(null);
  const [services, setServices] = useState<any[]>([]);

  useEffect(() => {
    setIsMounted(true);
    import('leaflet').then((L) => {
      setLeafletLib(L);
    });
  }, []);

  useEffect(() => {
    if (!isMounted || !incidentType) {
      setServices([]);
      return;
    }
    
    // Services will be populated from real incident data
    setServices([]);
  }, [isMounted, incidentType]);

  const severityColor = useMemo(() => {
    if (!severity) return '#3b82f6';
    if (severity.includes('High')) return '#ef4444';
    if (severity.includes('Medium')) return '#eab308';
    return '#22c55e';
  }, [severity]);

  const getServiceIcon = (s: any) => {
    if (!leafletLib) return null;
    let color = '#3b82f6';
    
    if (s.type === 'fire') color = '#f97316';
    else if (s.type === 'hospital') color = '#ef4444';
    else if (s.type === 'police') color = '#10b981';
    else if (s.type === 'power') color = '#eab308';
    else if (s.type === 'disaster') color = '#6366f1';

    return new leafletLib.DivIcon({
      html: `
        <div class="group relative flex items-center justify-center">
          <div style="background: ${color}; width: 34px; height: 34px; border-radius: 10px; border: 2.5px solid white; display: flex; align-items: center; justify-content: center; font-size: 16px; box-shadow: 0 8px 15px rgba(0,0,0,0.4); transform: rotate(-5deg); transition: transform 0.3s;" class="hover:rotate-0">
            ${s.emoji}
          </div>
        </div>
      `,
      className: 'custom-div-icon',
      iconSize: [34, 34],
      iconAnchor: [17, 17],
    });
  };

  const incidentIcon = useMemo(() => {
    if (!leafletLib) return null;
    return new leafletLib.DivIcon({
      html: `
        <div class="relative flex items-center justify-center">
          ${severity ? `<div class="absolute w-full h-full radar-pulse" style="background: ${severityColor}; border-radius: 50%;"></div>` : ''}
          <div style="background: ${severityColor}; width: 44px; height: 44px; border-radius: 50%; border: 4px solid white; box-shadow: 0 0 40px ${severityColor}; display: flex; align-items: center; justify-content: center; font-size: 22px; position: relative; z-index: 10;">
            ${severity ? '🚨' : '📡'}
          </div>
        </div>
      `,
      className: 'incident-icon',
      iconSize: [44, 44],
      iconAnchor: [22, 22],
    });
  }, [leafletLib, severity, severityColor]);

  if (!isMounted || !leafletLib) {
    return (
      <div className="w-full h-full bg-[#121212] flex items-center justify-center rounded-[2.5rem] border border-white/5 overflow-hidden">
        <Activity className="w-12 h-12 text-primary animate-pulse" />
      </div>
    );
  }

  const center: [number, number] = [location.latitude, location.longitude];

  return (
    <div className="relative w-full h-full bg-[#121212] overflow-hidden rounded-[2.5rem] border border-white/5 shadow-[0_0_80px_rgba(0,0,0,0.5)] animate-in fade-in zoom-in duration-700">
      <MapContainer center={center} zoom={14} scrollWheelZoom={true} className="w-full h-full z-0" zoomControl={false}>
        <ChangeView center={center} zoom={14} />
        <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />

        <Marker position={center} icon={incidentIcon}>
          <Popup className="custom-popup">
            <div className="p-2 font-black text-[10px] uppercase tracking-widest text-primary text-center">
              {incidentType || 'SENTINEL ACTIVE'}
            </div>
          </Popup>
        </Marker>

        {severity && (
          <Circle center={center} radius={800} pathOptions={{ fillColor: severityColor, color: severityColor, weight: 2, opacity: 0.3, fillOpacity: 0.05, dashArray: '10, 10' }} />
        )}

        {services.map((s, idx) => (
          <Marker key={idx} position={[location.latitude + s.offset[0], location.longitude + s.offset[1]]} icon={getServiceIcon(s)}>
            <Popup>
              <div className="p-3 font-black text-[11px] uppercase text-center space-y-2 min-w-[120px] bg-[#121212] rounded-xl">
                <div className="text-white leading-tight">{s.name}</div>
                <div className="text-white text-[10px] flex items-center justify-center gap-1 font-black bg-primary px-3 py-1 rounded-full shadow-lg">
                   <Navigation className="w-3 h-3" /> {s.dist}
                </div>
              </div>
            </Popup>
          </Marker>
        ))}
      </MapContainer>

      {/* Floating UI Overlays */}
      <div className="absolute top-6 left-6 z-[100] flex flex-col gap-3">
        <div className="glass-morphism px-5 py-3 rounded-2xl border border-white/10 flex items-center gap-3 shadow-2xl">
          <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center border border-primary/30">
            <Navigation className="w-4 h-4 text-primary animate-pulse" />
          </div>
          <div>
            <div className="text-[11px] font-black uppercase tracking-widest text-white leading-none">{location.city || 'GLOBAL NODE'}</div>
            <div className="text-[8px] font-black text-primary uppercase tracking-[0.2em] mt-1">SENTINEL SCAN ACTIVE</div>
          </div>
        </div>
      </div>

      {incidentType && (
        <div className="absolute bottom-6 left-6 right-6 z-[100] md:max-w-[320px]">
          <div className="glass-morphism p-5 rounded-[2rem] border border-white/10 space-y-4 shadow-2xl animate-in slide-in-from-bottom-4 duration-500">
            <div className="flex items-center justify-between">
              <h4 className="text-[10px] font-black uppercase tracking-[0.3em] text-muted-foreground">Nearby Authorities</h4>
              <div className="flex items-center gap-1.5">
                 <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
                 <span className="text-[8px] font-black uppercase tracking-widest opacity-50">GIS ACTIVE</span>
              </div>
            </div>
            <div className="space-y-3">
              {services.slice(0, 3).map((s, i) => (
                <div key={i} className="flex items-center justify-between group transition-transform">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-xl bg-white/5 flex items-center justify-center border border-white/10 text-primary group-hover:bg-primary/20">
                      {s.emoji}
                    </div>
                    <div className="flex flex-col">
                      <span className="text-[10px] font-black text-white/90 truncate w-[140px] uppercase leading-none">{s.name}</span>
                      <span className="text-[8px] font-bold text-muted-foreground uppercase mt-1">Dispatch Code: {s.type.toUpperCase()}</span>
                    </div>
                  </div>
                  <span className="text-[10px] font-black text-white bg-primary px-3 py-1 rounded-full shadow-md">{s.dist}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
