"use client";

import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ShieldCheck, Eye, EyeOff, Smartphone } from 'lucide-react';

const DEFAULT_CONFIG = {
  accountSid: 'ACcc5853a50df69ac555ba71cc85ae0652',
  authToken: '57ac33112c2d6bd1e7bd90ccd9100ad7',
  from: '+12279977537',
  to: '+919791462614',
};

export function SettingsModal({ isOpen, onClose }: any) {
  const [config, setConfig] = useState(DEFAULT_CONFIG);
  const [showSid, setShowSid] = useState(false);
  const [showToken, setShowToken] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem('sentinel_dispatch_config');
    if (saved) setConfig(JSON.parse(saved));
    else localStorage.setItem('sentinel_dispatch_config', JSON.stringify(DEFAULT_CONFIG));
  }, []);

  const handleSave = () => {
    localStorage.setItem('sentinel_dispatch_config', JSON.stringify(config));
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-[#121212] border-white/10 text-white max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl font-black uppercase text-primary">
            <Smartphone className="w-5 h-5" /> Config
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label className="text-[10px] uppercase font-black text-muted-foreground">Twilio Account SID</Label>
            <div className="relative">
              <Input type={showSid ? "text" : "password"} value={config.accountSid} onChange={(e) => setConfig({ ...config, accountSid: e.target.value })} className="bg-white/5 border-white/10 pr-10" />
              <button onClick={() => setShowSid(!showSid)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground">{showSid ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}</button>
            </div>
          </div>
          <div className="space-y-2">
            <Label className="text-[10px] uppercase font-black text-muted-foreground">Auth Token</Label>
            <div className="relative">
              <Input type={showToken ? "text" : "password"} value={config.authToken} onChange={(e) => setConfig({ ...config, authToken: e.target.value })} className="bg-white/5 border-white/10 pr-10" />
              <button onClick={() => setShowToken(!showToken)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground">{showToken ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}</button>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-[10px] uppercase font-black text-muted-foreground">From</Label>
              <Input value={config.from} onChange={(e) => setConfig({ ...config, from: e.target.value })} className="bg-white/5 border-white/10" />
            </div>
            <div className="space-y-2">
              <Label className="text-[10px] uppercase font-black text-muted-foreground">To</Label>
              <Input value={config.to} onChange={(e) => setConfig({ ...config, to: e.target.value })} className="bg-white/5 border-white/10" />
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button onClick={handleSave} className="w-full bg-primary font-black uppercase">Save Configuration</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}