"use client";

import React, { useState, useRef } from 'react';
import { Upload, Camera, FileVideo, Sparkles, MapPin, Activity, ShieldAlert, Loader2 } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface UploadSectionProps {
  onUpload: (dataUri: string) => void;
  isProcessing: boolean;
  progress: number;
  location: { city?: string; state?: string; country?: string; latitude: number; longitude: number };
}

export function UploadSection({ onUpload, isProcessing, progress, location }: UploadSectionProps) {
  const [dragActive, setDragActive] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);

  const handleFile = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      if (e.target?.result) {
        onUpload(e.target.result as string);
      }
    };
    reader.readAsDataURL(file);
  };

  const onDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") setDragActive(true);
    else if (e.type === "dragleave") setDragActive(false);
  };

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  return (
    <div className="flex flex-col gap-6 py-4 animate-in fade-in zoom-in duration-500 h-full max-w-full overflow-hidden">
      <div className="space-y-4 px-2">
        <div className="inline-flex items-center gap-2 px-3 py-1 bg-primary/20 border border-primary/30 rounded-full text-primary text-[10px] font-black tracking-widest uppercase">
          <Sparkles className="w-3 h-3 animate-pulse" />
          Neural Link Active
        </div>
        <h2 className="text-4xl font-black tracking-tighter text-white leading-none uppercase">
          SCAN <span className="text-primary">HORIZON</span>
        </h2>
        <div className="flex flex-wrap gap-2">
          <div className="flex items-center gap-2 text-[10px] font-black text-accent uppercase tracking-widest bg-accent/10 px-3 py-2 rounded-full border border-accent/20">
            <MapPin className="w-3.5 h-3.5" />
            {location.city || 'GLOBAL NODE'}
          </div>
          <div className="flex items-center gap-2 text-[10px] font-black text-green-500 uppercase tracking-widest bg-green-500/10 px-3 py-2 rounded-full border border-green-500/20">
            <Activity className="w-3.5 h-3.5" />
            READY
          </div>
        </div>
      </div>

      <Card 
        className={cn(
          "relative border-2 border-dashed border-white/10 bg-[#121212]/50 backdrop-blur-md p-6 transition-all cursor-pointer group hover:border-primary/40 overflow-hidden flex-1 flex items-center justify-center shadow-2xl min-h-[350px] rounded-[2rem]",
          dragActive && "border-primary bg-primary/5 scale-[1.01]",
          isProcessing && "pointer-events-none border-primary/50"
        )}
        onDragEnter={onDrag}
        onDragLeave={onDrag}
        onDragOver={onDrag}
        onDrop={onDrop}
        onClick={() => !isProcessing && fileInputRef.current?.click()}
      >
        {isProcessing && <div className="absolute inset-0 scanning-line" />}
        
        <input ref={fileInputRef} type="file" className="hidden" accept="image/*,video/*" onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])} />
        <input ref={cameraInputRef} type="file" className="hidden" accept="image/*" capture="environment" onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])} />
        <input ref={videoInputRef} type="file" className="hidden" accept="video/*" capture="environment" onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])} />
        
        <div className="flex flex-col items-center gap-8 text-center relative z-10 w-full px-4">
          {isProcessing ? (
            <div className="space-y-8 w-full max-w-[280px] animate-in fade-in scale-100 duration-500">
              <div className="relative flex items-center justify-center">
                <div className="w-40 h-40 rounded-full border-2 border-white/5 border-t-primary animate-spin" />
                <div className="absolute inset-0 flex flex-center flex-col items-center justify-center">
                  <ShieldAlert className="w-10 h-10 text-primary mb-2 animate-pulse" />
                  <span className="text-4xl font-black text-white">{Math.round(progress)}%</span>
                  <span className="text-[10px] font-black uppercase tracking-[0.2em] opacity-50">Decoding Feed</span>
                </div>
              </div>
              <div className="space-y-4">
                <div className="w-full bg-white/5 h-1.5 rounded-full overflow-hidden">
                  <div className="h-full bg-primary transition-all duration-300" style={{ width: `${progress}%` }} />
                </div>
                <p className="text-[11px] text-muted-foreground font-black tracking-[0.2em] uppercase">
                  Identifying Incident Cluster...
                </p>
              </div>
            </div>
          ) : (
            <>
              <div className="w-28 h-28 rounded-3xl bg-primary/10 flex items-center justify-center text-primary group-hover:scale-110 group-hover:rotate-3 transition-all duration-500 shadow-[0_0_50px_rgba(41,171,226,0.2)] border border-primary/20">
                <Upload className="w-12 h-12" />
              </div>
              <div className="space-y-2">
                <p className="text-3xl font-black tracking-tighter uppercase leading-none">Drop Feed</p>
                <p className="text-muted-foreground text-[11px] font-black tracking-widest uppercase">AI Incident Detection Engine</p>
              </div>
              
              <div className="grid grid-cols-2 gap-3 w-full max-w-sm">
                <Button 
                  onClick={(e) => { e.stopPropagation(); cameraInputRef.current?.click(); }}
                  className="bg-white/5 border border-white/10 h-16 rounded-2xl flex flex-col items-center justify-center gap-1 hover:bg-primary/20 hover:border-primary/50 transition-all text-[10px] font-black uppercase tracking-widest"
                >
                  <Camera className="w-5 h-5 text-primary" />
                  Live Photo
                </Button>
                <Button 
                  onClick={(e) => { e.stopPropagation(); videoInputRef.current?.click(); }}
                  className="bg-white/5 border border-white/10 h-16 rounded-2xl flex flex-col items-center justify-center gap-1 hover:bg-primary/20 hover:border-primary/50 transition-all text-[10px] font-black uppercase tracking-widest"
                >
                  <FileVideo className="w-5 h-5 text-primary" />
                  Live Video
                </Button>
              </div>
              <p className="text-[9px] font-black text-muted-foreground uppercase tracking-widest opacity-50">or drag & drop files from gallery</p>
            </>
          )}
        </div>
      </Card>
    </div>
  );
}
