export type UserLocation = {
  latitude: number;
  longitude: number;
  city?: string;
  state?: string;
  country?: string;
  mode: 'fixed' | 'gps' | 'manual';
};

export const KORAMANGALA_LOCATION: UserLocation = {
  latitude: 12.9352,
  longitude: 77.6245,
  city: 'Koramangala',
  state: 'Karnataka',
  country: 'India',
  mode: 'fixed'
};

export async function getCurrentLocation(): Promise<UserLocation> {
  return new Promise((resolve) => {
    if (typeof window === 'undefined' || !navigator.geolocation) {
      resolve({ ...KORAMANGALA_LOCATION, mode: 'gps' });
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        resolve({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          city: 'Local Area',
          state: 'Detected Region',
          country: 'Detected Country',
          mode: 'gps'
        });
      },
      () => {
        resolve({ ...KORAMANGALA_LOCATION, mode: 'gps' });
      }
    );
  });
}
