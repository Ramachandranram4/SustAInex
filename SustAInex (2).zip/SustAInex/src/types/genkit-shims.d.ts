declare module 'genkit' {
  export const z: any;
  export namespace z {
    type infer<T> = any;
  }

  export function genkit(options?: any): any;
  export function definePrompt(config: any): any;
  export function defineFlow(config: any, handler: any): any;
  export function runFlow(name: string, input?: any): Promise<any>;
}

declare module '@genkit-ai/google-genai' {
  function googleAI(config?: any): any;
  namespace googleAI {
    function model(name: string): any;
  }
  export { googleAI };
}

declare module 'wav' {
  export class Writer {
    constructor(options?: any);
    write(chunk: Buffer | Uint8Array): void;
    end(): void;
    on(event: string, listener: (...args: any[]) => void): this;
  }
}
